﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



    public class Line
    {
    public double x1, x2, y1, y2;

    //public Line lin1(Line lin)
    //{
    //    Line lin1 = new Line();
    //    Console.WriteLine("Vvedite 'X1' koordinati pervoi pryamoi : ");
    //    lin1.x1 = Convert.ToDouble(Console.ReadLine());
    //    Console.WriteLine("Vvedite 'X2' koordinati pervoi pryamoi : ");
    //    lin1.x2 = Convert.ToDouble(Console.ReadLine());
    //    Console.WriteLine("Vvedite 'Y1' koordinati pervoi pryamoi : ");
    //    lin1.y1 = Convert.ToDouble(Console.ReadLine());
    //    Console.WriteLine("Vvedite 'Y2' koordinati pervoi pryamoi : ");
    //    lin1.y2 = Convert.ToDouble(Console.ReadLine());
    //    return lin;
    //}

    //public void lin2()
    //{
    //    Line lin2 = new Line();
    //    Console.WriteLine("Vvedite 'X1' koordinati pervoi pryamoi : ");
    //    lin2.x1 = Convert.ToDouble(Console.ReadLine());
    //    Console.WriteLine("Vvedite 'X2' koordinati pervoi pryamoi : ");
    //    lin2.x2 = Convert.ToDouble(Console.ReadLine());
    //    Console.WriteLine("Vvedite 'Y1' koordinati pervoi pryamoi : ");
    //    lin2.y1 = Convert.ToDouble(Console.ReadLine());
    //    Console.WriteLine("Vvedite 'Y2' koordinati pervoi pryamoi : ");
    //    lin2.y2 = Convert.ToDouble(Console.ReadLine());
    //}


  

    }
