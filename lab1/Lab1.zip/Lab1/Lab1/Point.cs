﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Point 
    {
    public double x, y;
    public bool r;
    public Point(double x1, double y1, bool r1)
    {
        x = x1;
        y = y1;
        r = r1;
    }
}
